import os
from pathlib import Path

os.environ["DATABASE_URL"] = "sqlite:///./test_terragate_api.db"
os.environ["ARTIFACT_STORAGE_DIR"] = "./test_artifacts"
os.environ["GITHUB_TOKEN"] = ""

from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import MetaData  # noqa: E402

from app.auth.dev import DevUser, ROLE_PLATFORM_ADMIN, get_current_user  # noqa: E402
from app.config import get_settings  # noqa: E402
from app.db.init_db import init_db  # noqa: E402
from app.db.session import SessionLocal, engine  # noqa: E402
from app.main import app  # noqa: E402
from app.models import UserModel  # noqa: E402


ROOT = Path(__file__).resolve().parents[4]


def setup_module() -> None:
    metadata = MetaData()
    metadata.reflect(bind=engine)
    metadata.drop_all(bind=engine)
    init_db()


def test_auth_me_uses_dev_header_identity() -> None:
    with TestClient(app) as client:
        response = client.get(
            "/api/v1/auth/me",
            headers={
                "X-TerraGate-User-Email": "reviewer@example.com",
                "X-TerraGate-User-Name": "Review Lead",
                "X-TerraGate-Role": "reviewer",
            },
        )

    assert response.status_code == 200
    assert response.json() == {
        "id": "reviewer@example.com",
        "email": "reviewer@example.com",
        "name": "Review Lead",
        "role": "reviewer",
        "org_id": "dev",
        "groups": ["reviewer"],
        "auth_provider": "dev",
    }


def test_runtime_capabilities_do_not_expose_configuration_values() -> None:
    with TestClient(app) as client:
        response = client.get("/api/v1/runtime-capabilities")

    assert response.status_code == 200
    payload = response.json()
    assert payload["auth_provider"] == "dev"
    assert payload["github_reads"] == "disabled"
    assert payload["github_writes"] == "disabled"
    assert payload["cost_estimation"] == "heuristic"
    assert payload["max_upload_bytes"] is None
    assert "github_token" not in payload
    assert "database_url" not in payload


def test_review_creation_is_role_gated() -> None:
    with TestClient(app) as client:
        response = client.post(
            "/api/v1/terraform-reviews",
            headers={"X-TerraGate-Role": "viewer"},
            data={"environment": "dev", "cloud_provider": "aws"},
        )

    assert response.status_code == 403


def test_create_review_requires_approval_before_github_post() -> None:
    plan_path = ROOT / "sample-data" / "terraform-plans" / "risky-security-plan.json"
    with TestClient(app) as client:
        with plan_path.open("rb") as file:
            response = client.post(
                "/api/v1/terraform-reviews",
                files={"file": ("risky-security-plan.json", file, "application/json")},
                data={
                    "environment": "prod",
                    "cloud_provider": "aws",
                    "repo_owner": "example",
                    "repo_name": "infra",
                    "pull_number": "42",
                    "policy_profile": "default",
                },
            )

        assert response.status_code == 200, response.text
        run_id = response.json()["run_id"]

        run = client.get(f"/api/v1/runs/{run_id}")
        assert run.status_code == 200
        assert run.json()["github_pr_context"]["mock"] is True
        assert "GITHUB_TOKEN" in run.json()["github_pr_context"]["message"]
        assert run.json()["job"]["status"] == "completed"
        assert run.json()["github_check"]["status"] == "completed"
        assert run.json()["audit_event_count"] >= 3

        blocked = client.post(f"/api/v1/runs/{run_id}/github-comment")
        assert blocked.status_code == 409

        report = client.get(f"/api/v1/runs/{run_id}/report").json()
        approved = client.post(f"/api/v1/runs/{run_id}/approve", json={"notes": "demo approved", "review_snapshot_hash": report["review_snapshot_hash"]})
        assert approved.status_code == 200

        posted = client.post(f"/api/v1/runs/{run_id}/github-comment")
        assert posted.status_code == 200
        assert posted.json()["mock"] is True
        assert "GITHUB_TOKEN" in posted.json()["message"]

        patches = client.get(f"/api/v1/runs/{run_id}/fix-patches")
        assert patches.status_code == 200
        assert patches.json()
        patch_id = patches.json()[0]["id"]
        assert patches.json()[0]["kind"] == "snippet"
        assert patches.json()[0]["snippet"]
        assert patches.json()[0]["diff"] == ""

        progress_empty = client.get(f"/api/v1/runs/{run_id}/runbook-progress")
        assert progress_empty.status_code == 200
        assert progress_empty.json() == []

        progress_update = client.put(
            f"/api/v1/runs/{run_id}/runbook-progress/backup-1",
            json={"checked": True, "section_id": "backup"},
        )
        assert progress_update.status_code == 200
        assert progress_update.json()["checked"] is True
        assert progress_update.json()["section_id"] == "backup"

        progress_saved = client.get(f"/api/v1/runs/{run_id}/runbook-progress")
        assert progress_saved.status_code == 200
        assert progress_saved.json()[0]["step_id"] == "backup-1"

        blocked_patch_commit = client.post(f"/api/v1/runs/{run_id}/fix-patches/{patch_id}/github-commit")
        assert blocked_patch_commit.status_code == 409

        patch_approval = client.post(f"/api/v1/runs/{run_id}/fix-patches/{patch_id}/approve", json={"review_snapshot_hash": patches.json()[0]["review_snapshot_hash"]})
        assert patch_approval.status_code == 409
        assert "snippet" in patch_approval.json()["detail"]

        patch_commit = client.post(f"/api/v1/runs/{run_id}/fix-patches/{patch_id}/github-commit")
        assert patch_commit.status_code == 409

        audit = client.get(f"/api/v1/runs/{run_id}/audit-log")
        assert audit.status_code == 200
        assert any(entry["action"] == "approval.approved" for entry in audit.json())
        assert not any(entry["action"] == "fix_patch.commit_mocked" for entry in audit.json())
        assert any(entry["action"] == "runbook.step_checked" for entry in audit.json())


def test_runs_are_scoped_to_authenticated_org() -> None:
    plan_path = ROOT / "sample-data" / "terraform-plans" / "safe-plan.json"
    alpha_user = DevUser(
        id="alpha-admin",
        email="alpha@example.com",
        name="Alpha Admin",
        role=ROLE_PLATFORM_ADMIN,
        org_id="alpha",
        groups=[ROLE_PLATFORM_ADMIN],
        auth_provider="dev",
    )
    beta_user = DevUser(
        id="beta-admin",
        email="beta@example.com",
        name="Beta Admin",
        role=ROLE_PLATFORM_ADMIN,
        org_id="beta",
        groups=[ROLE_PLATFORM_ADMIN],
        auth_provider="dev",
    )

    app.dependency_overrides[get_current_user] = lambda: alpha_user
    try:
        with TestClient(app) as client:
            response = client.post(
                "/api/v1/terraform-reviews/json",
                json={
                    "file_name": "safe-plan.json",
                    "plan_json_text": plan_path.read_text(),
                    "environment": "dev",
                    "cloud_provider": "aws",
                    "policy_profile": "default",
                },
            )
            assert response.status_code == 200, response.text
            run_id = response.json()["run_id"]

            alpha_run = client.get(f"/api/v1/runs/{run_id}")
            assert alpha_run.status_code == 200

            app.dependency_overrides[get_current_user] = lambda: beta_user
            beta_run = client.get(f"/api/v1/runs/{run_id}")
            beta_runs = client.get("/api/v1/runs")
            beta_approval = client.post(f"/api/v1/runs/{run_id}/approve", json={"notes": "wrong org", "review_snapshot_hash": "0" * 64})

        assert beta_run.status_code == 404
        assert beta_approval.status_code == 404
        assert run_id not in {item["id"] for item in beta_runs.json()}
    finally:
        app.dependency_overrides.clear()


def test_pr_context_preview_returns_clear_dev_placeholder_without_token() -> None:
    with TestClient(app) as client:
        response = client.get(
            "/api/v1/github/pr-context",
            params={"repo_owner": "example", "repo_name": "infra", "pull_number": "42"},
        )

    assert response.status_code == 200
    payload = response.json()
    assert payload["available"] is False
    assert payload["mock"] is True
    assert payload["repo_full_name"] == "example/infra"


def test_sandbox_execution_is_explicitly_opt_in() -> None:
    with TestClient(app) as client:
        response = client.post(
            "/api/v1/terraform-reviews",
            data={
                "execution_mode": "sandbox_plan",
                "terraform_working_dir": "demo-infra",
            },
        )

    assert response.status_code == 400
    assert "TERRAFORM_SANDBOX_ENABLED" in response.json()["detail"]


def test_github_webhook_requires_plan_execution_configuration(monkeypatch) -> None:
    payload = {
        "action": "opened",
        "repository": {
            "name": "infra",
            "full_name": "example/infra",
            "owner": {"login": "example"},
        },
        "pull_request": {
            "number": 42,
            "head": {"sha": "abc123"},
        },
    }
    import hashlib
    import hmac
    import json
    from app.config import get_settings
    monkeypatch.setattr(get_settings(), "github_webhook_secret", "test-webhook-secret")
    body = json.dumps(payload).encode()
    signature = "sha256=" + hmac.new(b"test-webhook-secret", body, hashlib.sha256).hexdigest()
    with TestClient(app) as client:
        response = client.post(
            "/api/v1/github/webhook",
            headers={"X-GitHub-Event": "pull_request", "X-Hub-Signature-256": signature, "Content-Type": "application/json"},
            content=body,
        )

    assert response.status_code == 202
    assert response.json()["accepted"] is False
    assert "GITHUB_WEBHOOK_TERRAFORM_WORKING_DIR" in response.json()["reason"]


def test_policy_pack_update_is_role_gated() -> None:
    with TestClient(app) as client:
        blocked = client.put(
            "/api/v1/policy-packs/default",
            headers={"X-TerraGate-Role": "viewer"},
            json={"max_monthly_delta": 900},
        )
        allowed = client.get("/api/v1/policy-packs/default")

    assert blocked.status_code == 403
    assert allowed.status_code == 200
    assert allowed.json()["name"] == "default"


def test_demo_sample_review_runs_without_upload_or_auth_headers() -> None:
    os.environ["PUBLIC_DEMO_MODE"] = "true"
    get_settings.cache_clear()
    try:
        with TestClient(app) as client:
            response = client.post("/api/v1/demo/terraform-reviews", json={"sample": "risky-cost"})

            assert response.status_code == 200, response.text
            run_id = response.json()["run_id"]
            run = client.get(f"/api/v1/runs/{run_id}")

        assert run.status_code == 200
        payload = run.json()
        assert payload["terraform_execution"]["mode"] == "demo_sample"
        assert payload["terraform_execution"]["sample"] == "risky-cost"
        assert payload["job"]["status"] == "completed"
        assert payload["risk_score"] > 0
    finally:
        os.environ.pop("PUBLIC_DEMO_MODE", None)
        get_settings.cache_clear()


def test_json_upload_review_runs_in_public_demo_mode() -> None:
    plan_path = ROOT / "sample-data" / "terraform-plans" / "risky-security-plan.json"
    os.environ["PUBLIC_DEMO_MODE"] = "true"
    get_settings.cache_clear()
    try:
        with TestClient(app) as client:
            response = client.post(
                "/api/v1/terraform-reviews/json",
                json={
                    "file_name": "risky-security-plan.json",
                    "plan_json_text": plan_path.read_text(),
                    "environment": "prod",
                    "cloud_provider": "aws",
                    "policy_profile": "default",
                },
            )
            assert response.status_code == 200, response.text
            run_id = response.json()["run_id"]
            run = client.get(f"/api/v1/runs/{run_id}")

        assert run.status_code == 200
        payload = run.json()
        assert payload["terraform_execution"]["mode"] == "uploaded_plan"
        assert payload["job"]["status"] == "completed"
        assert payload["risk_score"] > 0
        with SessionLocal() as db:
            assert db.get(UserModel, "dev@terragate.local") is not None
    finally:
        os.environ.pop("PUBLIC_DEMO_MODE", None)
        get_settings.cache_clear()


def test_public_demo_upload_limit_rejects_large_plans() -> None:
    plan_path = ROOT / "sample-data" / "terraform-plans" / "safe-plan.json"
    os.environ["PUBLIC_DEMO_MODE"] = "true"
    os.environ["PUBLIC_DEMO_MAX_UPLOAD_BYTES"] = "10"
    get_settings.cache_clear()
    try:
        with TestClient(app) as client:
            with plan_path.open("rb") as file:
                response = client.post(
                    "/api/v1/terraform-reviews",
                    files={"file": ("safe-plan.json", file, "application/json")},
                    data={"environment": "dev", "cloud_provider": "aws"},
                )

        assert response.status_code == 413
        assert "Public demo uploads are limited" in response.json()["detail"]
    finally:
        os.environ.pop("PUBLIC_DEMO_MODE", None)
        os.environ.pop("PUBLIC_DEMO_MAX_UPLOAD_BYTES", None)
        get_settings.cache_clear()


def test_public_demo_json_upload_limit_rejects_large_plans() -> None:
    plan_path = ROOT / "sample-data" / "terraform-plans" / "safe-plan.json"
    os.environ["PUBLIC_DEMO_MODE"] = "true"
    os.environ["PUBLIC_DEMO_MAX_UPLOAD_BYTES"] = "10"
    get_settings.cache_clear()
    try:
        with TestClient(app) as client:
            response = client.post(
                "/api/v1/terraform-reviews/json",
                json={
                    "file_name": "safe-plan.json",
                    "plan_json_text": plan_path.read_text(),
                    "environment": "dev",
                    "cloud_provider": "aws",
                },
            )

        assert response.status_code == 413
        assert "Public demo uploads are limited" in response.json()["detail"]
    finally:
        os.environ.pop("PUBLIC_DEMO_MODE", None)
        os.environ.pop("PUBLIC_DEMO_MAX_UPLOAD_BYTES", None)
        get_settings.cache_clear()


def test_public_demo_policy_packs_are_read_only() -> None:
    os.environ["PUBLIC_DEMO_MODE"] = "true"
    get_settings.cache_clear()
    try:
        with TestClient(app) as client:
            response = client.put(
                "/api/v1/policy-packs/default",
                json={"max_monthly_delta": 900},
            )

        assert response.status_code == 403
        assert "read-only in public demo mode" in response.json()["detail"]
    finally:
        os.environ.pop("PUBLIC_DEMO_MODE", None)
        get_settings.cache_clear()
